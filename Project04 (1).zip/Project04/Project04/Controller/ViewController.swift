//
//  ViewController.swift
//  Project04
//
//  Created by wsucatslabs on 10/16/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

